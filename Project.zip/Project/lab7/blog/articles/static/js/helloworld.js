var groupmates = [
    {
        "name": "Михаил",
        "group": "912-1",
        "age": 19,
        "marks": [4, 4, 5, 5, 3]
    },
    {
        "name": "Алексей",
        "group": "912-1",
        "age": 20,
        "marks": [4, 3, 3, 3, 3]
    },
    {
        "name": "Николай",
        "group": "912-1",
        "age": 21,
        "marks": [4, 5, 5, 5, 4]
    },
    {
        "name": "Александр",
        "group": "912-2",
        "age": 22,
        "marks": [4, 4, 3, 4, 4]
    },
    {
        "name": "Кирилл",
        "group": "912-2",
        "age": 23,
        "marks": [3, 3, 3, 3, 3]
    }
];

// console.log(groupmates);

var rpad = function(str, length) {
    // js не поддерживает добавление нужного количества символов 
    // справа от строки то есть аналога ljust из языка Python здесь нет
    str = str.toString(); // преобразование в строку
    while (str.length < length)
        str = str + ' '; // добавление пробела в конец строки
    return str; // когда все пробелы добавлены, возвратить строку
};
var printStudents = function(students){
    console.log(
        rpad("Имя студента", 15),
        rpad("Группа", 8),
        rpad("Возраст", 8),
        rpad("Оценки", 20)
    );
    // был выведен заголовок таблицы
    for (var i = 0; i<=students.length-1; i++){
        // в цикле выводится каждый экземпляр студента
        console.log(
            rpad(students[i]['name'], 15),
            rpad(students[i]['group'], 8),
            rpad(students[i]['age'], 8),
            rpad(students[i]['marks'], 20)
        );
    }
    console.log('\n'); // добавляется пустая строка в конце вывода
};

function filterGroup(students, group) {
    return students.filter(function(student) {
        return student.group === group;
    });
}

printStudents(groupmates);

var result = filterGroup(groupmates, "912-1");
console.log(result);

// var foldBtns = document.getElementsByClassName("fold-button");

// for (let i = 0; i < foldBtns.length; i++) {
//     foldBtns[i].addEventListener("click", function(event) {
   
//         const parent = event.target.parentElement;
        

//         const author = parent.querySelector('.article-author');
//         const date = parent.querySelector('.article-created-date');
//         const text = parent.querySelector('.article-text');

        
//         if (text.style.display === "none") {
//             author.style.display = "block"; 
//             date.style.display = "block";
//             text.style.display = "block";
//             event.target.innerHTML = "свернуть";
//         } else {
            
//             author.style.display = "none";
//             date.style.display = "none";
//             text.style.display = "none";
//             event.target.innerHTML = "развернуть";
//         }
//     });
// }

var foldBtns = document.getElementsByClassName("fold-button");

for (let i = 0; i < foldBtns.length; i++) {
    foldBtns[i].addEventListener("click", function(event) {
   
        const post = event.target.closest('.one-post');
        
        
        const isFolded = post.classList.toggle('folded');
        
        
        event.target.innerHTML = isFolded ? "развернуть" : "свернуть";
    });
}