# -*- coding: utf-8 -*-

from models import Article
from django.http import Http404
from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login

def archive(request):
    return render(request, 'archive.html', {"posts": Article.objects.all()})

def get_article(request, article_id):
    try:
        post = Article.objects.get(id=article_id)
        return render(request, 'article.html', {"post": post})
    except Article.DoesNotExist:
        raise Http404

def create_post(request):
    if not request.user.is_anonymous():
        if request.method == "POST":
        
            # обработать данные формы, если метод POST
            form = {
                'text': request.POST["text"],
                'title': request.POST["title"]
            }
            # в словаре form будет храниться информация, введенная пользователем
            if form["text"] and form["title"]:
                # если поля заполнены без ошибок
                if Article.objects.filter(title=form["title"]).exists():
                    # Если нашли — возвращаем ошибку в шаблон
                    form['errors'] = u"Пост уже существует"
                    return render(request, 'create_post.html', {'form': form})
                    
                idNewArticle = Article.objects.create(text=form["text"], title=form["title"], author=request.user)
                return redirect('get_article', article_id=idNewArticle.id)  
                # перейти на страницу поста
            else:
                # если введенные данные некорректны
                form['errors'] = u"Не все поля заполнены"
                return render(request, 'create_post.html', {'form': form})
        else:
            # просто вернуть страницу с формой, если метод GET
            return render(request, 'create_post.html', {})
    else:
        raise Http404


def create_user(request):
    if request.method == "POST":
        form = {
            'name': request.POST["name"],
            'mail': request.POST["mail"],
            'pass': request.POST["pass"]
        }
        if form["name"] and form["mail"] and form["pass"]:
            try:
                User.objects.get(username=form['name'])
                form['errors'] = u"Такой юзер уже есть"
                return render(request, 'create_user.html', {'form': form})
            except User.DoesNotExist:
                User.objects.create_user(form["name"], form["mail"], form["pass"])
                form['errors'] = u"Пользователь создан"
                return render(request, 'create_user.html', {'form': form})
        else:
            form['errors'] = u"Форма заполнена неверно"
            return render(request, 'create_user.html', {'form': form})
    else:
        return render(request, 'create_user.html', {})

def auth_user(request):
    if request.method == "POST":
        form = {
            'name': request.POST["name"],
            'pass': request.POST["pass"],
        }
        if form["name"] and form["pass"]:
            user = authenticate(username=form["name"], password=form["pass"])
            if user:
                login(request, user)
                form['errors'] = u"Пользователь авторизован"
                return render(request, 'auth_user.html', {'form': form})
            else:
                form['errors'] = u"Нет аккаунта с таким сочетанием никнейма и пароля"
                return render(request, 'auth_user.html', {'form': form})
        else:
            form['errors'] = u"Форма заполнена неверно"
            return render(request, 'auth_user.html', {'form': form})
    else:
        return render(request, 'auth_user.html', {})