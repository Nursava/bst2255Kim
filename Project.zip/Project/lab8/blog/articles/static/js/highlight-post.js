$(document).ready(function(){
 $('.one-post').hover(function(event){
 console.log("Навели");
 }, function(event){
 console.log("Вывели");
 });
});

$(document).ready(function(){
 $('.one-post').hover(function(event){
 $(event.currentTarget).find('.one-post-shadow').animate({opacity:
'0.1'}, 300);
 }, function(event){
$(event.currentTarget).find('.one-post-shadow').animate({opacity: '0'},
300);
 })
});

$(document).ready(function() {

    $('.logo').hover(
        function() {
            $(this).stop().animate({
                width: '+=20px'
            }, 300); 
        }, 
        function() {
            $(this).stop().animate({
                width: '-=20px'
            }, 300);
        }
    );
});