# -*- coding: utf-8 -*-
groupmates = [
    {
        "name": u"Михаил",
        "group": "912-1",
        "age": 19,
        "marks": [4, 4, 5, 5, 3]
    },
    {
        "name": u"Алексей",
        "group": "912-1",
        "age": 20,
        "marks": [4, 3, 3, 3, 3]
    },
    {
        "name": u"Николай",
        "group": "912-1",
        "age": 21,
        "marks": [4, 5, 5, 5, 4]
    },
    {
        "name": u"Александр",
        "group": "912-2",
        "age": 22,
        "marks": [4, 4, 3, 4, 4]
    },
    {
        "name": u"Кирилл",
        "group": "912-2",
        "age": 23,
        "marks": [3, 3, 3, 3, 3]
    }
]


def print_students(students):
    print u"Имя студента".ljust(15), \
          u"Группа".ljust(8), \
          u"Возраст".ljust(8), \
          u"Оценки".ljust(20)
    for student in students:
        print \
            student["name"].ljust(15), \
            student["group"].ljust(8), \
            str(student["age"]).ljust(8), \
            str(student["marks"]).ljust(20)
    print "\n" 


def filterAverageMark(students, mark):
    passed_students = []
    
    for student in students:
        average = sum(student['marks']) / 5.0
        
        if average > mark:
            passed_students.append(student)
            
    return passed_students

print_students(groupmates)

# print(filterAverageMark(groupmates, 3).encode('utf-8'))

for student in filterAverageMark(groupmates, 4):
    print(student["name"])
